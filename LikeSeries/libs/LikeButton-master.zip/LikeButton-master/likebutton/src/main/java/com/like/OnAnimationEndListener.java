package com.like;

public interface OnAnimationEndListener {
    void onAnimationEnd(LikeButton likeButton);
}
