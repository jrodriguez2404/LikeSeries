package com.like;

/**
 * Created by Joel on 23/12/2015.
 */
public enum IconType {
    Heart,
    Thumb,
    Star
}
